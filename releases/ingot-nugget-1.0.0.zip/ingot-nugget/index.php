<?php
//silence may or may not be golden.
